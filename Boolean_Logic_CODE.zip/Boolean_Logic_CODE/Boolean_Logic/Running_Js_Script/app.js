console.log("HELLO FROM OUR FIRST JS FILE!!!!");
let total = 1 + 3;
console.log("GOODBYE!");
